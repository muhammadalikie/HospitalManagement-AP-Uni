public interface Reminder {
    public void save();
    public void remove();
}
