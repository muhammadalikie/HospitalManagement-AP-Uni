
public class Person {
    protected String name;
    protected int nCode;

    public Person(String name, int nCode) {
        this.name = name;
        this.nCode = nCode;
    }
}